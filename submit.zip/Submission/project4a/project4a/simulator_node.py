import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64, String
import os
import tempfile
from geometry_msgs.msg import TransformStamped
import tf2_ros
import tf2_geometry_msgs
import math
import random
from geometry_msgs.msg import Quaternion
import yaml
import xml.etree.ElementTree as ET
import json
import xmltodict 
from geometry_msgs.msg import TransformStamped, Quaternion, Vector3
import numpy as np
from project4a.disc_robot import load_disc_robot, disc_robot_urdf
import yaml

class SimulatorNode(Node):

    def __init__(self):
        super().__init__('simulator_node')
        self.get_logger().info(f"Started simulator_node")

	# Set the timer for the callback function
        timer_period = 0.1
        self.timer = self.create_timer(timer_period, self.timer_callback)

        # Subscriber for vl
        self.vl_subscription = self.create_subscription(Float64, '/vl', self.vl_callback, 10)
        self.vl_subscription

        # Subscriber for vr
        self.vr_subscription = self.create_subscription(Float64, '/vr',self.vr_callback, 10)
        self.vr_subscription
        
        # Declare parameters for the robot
        self.declare_parameter('radius', 0.0)
        self.declare_parameter('distance', 0.0)
        self.declare_parameter('height', 0.0)
        self.declare_parameter('error_variance_left', 0.0)
        self.declare_parameter('error_variance_right', 0.0)
        self.declare_parameter('error_update_rate', 0.0)

	# Get parameter values
        self.radius = self.get_parameter('radius').value
        self.distance = self.get_parameter('distance').value
        self.height = self.get_parameter('height').value
        self.error_variance_left = self.get_parameter('error_variance_left').value
        self.error_variance_right = self.get_parameter('error_variance_right').value
        self.error_update_rate = self.get_parameter('error_update_rate').value

        # Initialize pose and transform variables
	self.pose = {'x': 0.0, 'y': 0.0, 'theta': 0.0}
        # self.last_update_time = self.get_clock().now()
		
        # Set up the initial transform from world to base_link
        self.base_link_transform = TransformStamped()
        self.base_link_transform.header.frame_id = 'world'
        self.base_link_transform.child_frame_id = 'base_link'
        
        # Initialize TF2 Broadcaster
        self.tf_broadcaster = tf2_ros.TransformBroadcaster(self)
        
        # initial velocities
        self.vl = 0.0
        self.vr = 0.0
        
        # Initialize error variables
        self.error_left = 0.0  # Initialize with no error
        self.error_right = 0.0  # Initialize with no error
        
        # Initialize timestamp for velocity commands and error update
        self.last_velocity_update_time = self.get_clock().now()
        self.last_error_update_time = self.get_clock().now()

    #callback for when vl is received
    def vl_callback(self, msg):
        self.get_logger().info(f"Current vl: {msg.data}")
        self.vl = msg.data
        self.last_velocity_update_time = self.get_clock().now()
        if self.error_left != 0.0:
            self.vl = self.vl * self.error_left

        

    #callback for when vl is received
    def vr_callback(self, msg):
        self.get_logger().info(f"Current vr: {msg.data}")
        self.vr = msg.data
        self.last_velocity_update_time = self.get_clock().now()
        if self.error_right != 0.0:
            self.vr = self.vr * self.error_right

    # Timer callback function        
    def timer_callback(self):
         # Calculate elapsed time since last velocity update
         current_time = self.get_clock().now()
         elapsed_time_velocity = (current_time - self.last_velocity_update_time).nanoseconds / 1e9
         elapsed_time_error = (current_time - self.last_error_update_time).nanoseconds / 1e9
         
         # If no velocity command received for 1 second, stop the robot
         if elapsed_time_velocity > 1.0:
             self.vl = 0.0
             self.vr = 0.0
             
         # Update the errors if the error_update_rate is reached
         if elapsed_time_error >= self.error_update_rate:
             self.update_errors()
         
         self.update_robot_pose(elapsed_time_velocity)

         # Broadcast the transform
         self.broadcast_transform()

         
    def update_errors(self):
        # Update the errors for left and right wheels with random values
        self.error_left = random.gauss(1.0, self.error_variance_left)
        self.error_right = random.gauss(1.0, self.error_variance_right)
        self.last_error_update_time = self.get_clock().now()
        self.get_logger().info(f'error_left = {self.error_left}, error_right = {self.error_right}')
         

    def update_robot_pose(self, time):
        # Update robot pose based on velocities and errors
        omega = (self.vr - self.vl) / self.distance
        omega_t = omega * 0.1
        if self.vl == self.vr:
            R = 10000000000.0 # icc at infinity
        elif self.vl == -self.vr: 
            R = 0
        else:
            R = (self.distance / 2) * (self.vr + self.vl) / (self.vr - self.vl)
            
        c = [self.pose['x'] - R * math.sin(self.pose['theta']), self.pose['y'] + R * math.cos(self.pose['theta'])]
        cos_omega_t = math.cos(omega_t)
        sin_omega_t = math.sin(omega_t)

        if self.vl == self.vr:
            # If the velocities are equal, then this is the equation we use
            self.pose['x'] =  self.pose['x'] + self.vl * math.cos(self.pose['theta'])*0.1
            self.pose['y'] =  self.pose['y'] + self.vl * math.sin(self.pose['theta'])*0.1

        else:
            # If the velocities are not equal
            self.pose['x'] = cos_omega_t * (self.pose['x'] - c[0]) - sin_omega_t * (self.pose['y'] - c[1]) + c[0]
            self.pose['y'] = sin_omega_t * (self.pose['x'] - c[0]) + cos_omega_t * (self.pose['y'] - c[1]) + c[1]
            self.pose['theta'] = self.pose['theta'] + omega_t
        
        self.get_logger().info(f"x : {self.pose['x']}, y : {self.pose['y']}, theta : {self.pose['theta']}")
       
    def broadcast_transform(self):
        # Broadcast the transform from world to base_link
	# Get the current time and set it as the stamp for the transform
        self.base_link_transform.header.stamp = self.get_clock().now().to_msg()
	    
	# Set the translation values of the transform
        self.base_link_transform.transform.translation.x = self.pose['x']
        self.base_link_transform.transform.translation.y = self.pose['y']

	# Calculate quaternion values for the rotation from the robot's theta angle
        quat_tf = [0.0, 0.0, math.sin(self.pose['theta']/2), math.cos(self.pose['theta']/2)]
        quaternion = Quaternion(x=quat_tf[0], y=quat_tf[1], z=quat_tf[2], w=quat_tf[3])

	# Set the rotation of the transform using the calculated quaternion
        self.base_link_transform.transform.rotation = quaternion

	# Send the transform using the TF2 Broadcaster
        self.tf_broadcaster.sendTransform(self.base_link_transform) 
        
def main(args=None):
    rclpy.init(args=args)
    simulator_node = SimulatorNode()
    rclpy.spin(simulator_node)
    simulator_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
